import { state } from './state.js';
import { UI } from './ui.js';

export const SocketClient = {
    init: () => {
        if (typeof io === 'undefined') {
            console.error("Socket.io library not found.");
            return;
        }

        try {
            const socket = io();
            state.socket = socket;

            socket.on('connect', () => UI.updateSocketStatus('🟢 在线', 'text-success'));
            socket.on('disconnect', () => { 
                UI.updateSocketStatus('🔴 离线', 'text-danger'); 
                UI.updateGlobalBar(false);
                state.currentMonitoredApp = null;
            });

            // 业务日志监听
            socket.on('network_log', UI.renderNetworkLog);
            socket.on('file_log', UI.renderFileLog);
            socket.on('info_log', UI.renderInfoLog);
            socket.on('sys_log', (data) => console.log("[System]", data.msg));

        } catch (e) {
            console.error("Socket init failed:", e);
        }
    }
};